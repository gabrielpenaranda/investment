<?php

declare(strict_types=1);

return [
    'english'   => 'Inglés',
    'spanish' => 'Español',
];