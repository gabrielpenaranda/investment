<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SystemProvider::class,
    App\Providers\VoltServiceProvider::class,
];
