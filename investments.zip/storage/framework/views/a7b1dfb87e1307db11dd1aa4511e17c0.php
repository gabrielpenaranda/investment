<div>
    <!--[if BLOCK]><![endif]--><?php if($interestMonth && !$interestMonth->processed): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.interests.generate')): ?>
            <a href="<?php echo e(route('admin.interests.generate', $interestMonth)); ?>" class="btn btn-primary">
                <?php echo e(__('messages.Generate Interests')); ?>

            </a>
        <?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($interestMonth && $interestMonth->processed && !$interestMonth->approved): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.interests.approve')): ?>
            <a href="<?php echo e(route('admin.interests.approve', $interestMonth)); ?>" class="btn btn-success">
                <?php echo e(__('messages.Approve Interests')); ?>

            </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.interests.rollback')): ?>
            <a href="<?php echo e(route('admin.interests.rollback')); ?>" class="btn btn-danger ml-2">
                <?php echo e(__('messages.Rollback Interests')); ?>

            </a>
        <?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($interestMonth && $interestMonth->processed && $interestMonth->approved): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.interests.pay')): ?>
            <a href="<?php echo e(route('admin.interests.payall')); ?>" class="btn btn-info">
                <?php echo e(__('messages.Mark all as paid')); ?>

            </a>
        <?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /home/gpg/Code/laravel/investments/resources/views/livewire/system/admin/interests-buttons.blade.php ENDPATH**/ ?>