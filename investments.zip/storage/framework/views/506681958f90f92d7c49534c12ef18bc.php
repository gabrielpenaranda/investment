


<div class="flex items-center justify-center">
    <?php if (isset($component)) { $__componentOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon-white','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon-white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac)): ?>
<?php $attributes = $__attributesOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac; ?>
<?php unset($__attributesOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac)): ?>
<?php $component = $__componentOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac; ?>
<?php unset($__componentOriginal02bf9dbd34b9bb7af3b8274a0b4cf3ac); ?>
<?php endif; ?>
</div>


<?php /**PATH /home/gpg/Code/laravel/investments/resources/views/components/app-logo-white.blade.php ENDPATH**/ ?>