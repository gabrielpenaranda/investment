

<img src="<?php echo e(asset('images/Logo APF color.png')); ?>">
<?php /**PATH /home/gpg/Code/laravel/investments/resources/views/components/app-logo-icon-auth.blade.php ENDPATH**/ ?>