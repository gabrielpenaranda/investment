<?php if (isset($component)) { $__componentOriginalfefb4fd9b7004fa65f70c415ac76903e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.site','data' => ['title' => __('Welcome')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Welcome'))]); ?>


    <nav x-data="{ scrolled: false, isOpen: false }" 
     @scroll.window="scrolled = window.scrollY > 0"
     :class="scrolled ? 'bg-white text-[#162C48]' : 'bg-black text-white'" 
     class="sticky top-0 z-50 transition-all duration-300">
    <div class="container mx-auto px-4 py-3 flex items-center justify-between">
        <!-- Hamburguesa (visible en móviles y tablets) -->
        <div class="xl:hidden">
            <button @click="isOpen = !isOpen" class="text-2xl focus:outline-none">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <!-- Logo -->
        <div class="flex justify-center xl:justify-start w-full xl:w-auto">
            <img 
                :src="scrolled ? '<?php echo e(asset('images/LOGO APF.svg')); ?>' : '<?php echo e(asset('images/LOGO APF blanco.svg')); ?>'" 
                alt="Asset Performance Fund" 
                class="h-10 mx-auto xl:mx-0"
            >
        </div>

        <!-- Menú de navegación (oculto en móviles y tablets) -->
        <nav class="hidden xl:flex space-x-6">
            <a href="#home" class="hover:text-blue-400"><?php echo e(__('site.home')); ?></a>
            <a href="#services" class="hover:text-blue-400"><?php echo e(__('site.services')); ?></a>
            <a href="#information" class="hover:text-blue-400"><?php echo e(__('site.fund')); ?></a>
            <a href="#team" class="hover:text-blue-400"><?php echo e(__('site.team')); ?></a>
            <a href="#faq" class="hover:text-blue-400"><?php echo e(__('site.faq')); ?></a>
            <a href="#docs" class="hover:text-blue-400"><?php echo e(__('site.docs')); ?></a>
            <a href="#contact" class="hover:text-blue-400"><?php echo e(__('site.contact')); ?></a>
        </nav>

        <!-- Botones y opciones -->
        <div class="hidden xl:flex items-center space-x-6">
            <div class="flex items-center space-x-2">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('system.language-selector');

$__html = app('livewire')->mount($__name, $__params, 'lw-2390008740-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="flex items-center space-x-2">
                <i class="fas fa-lock text-sm"></i>
                <a href="<?php echo e(route('login')); ?>"><span><?php echo e(__('site.login')); ?></span></a>
            </div>
            <button class="bg-azul-secondary hover:bg-azul-primary text-white px-4 py-2 rounded-lg font-medium">
                <?php echo e(__('site.invest_now')); ?>

            </button>
        </div>
    </div>

    <!-- Menú desplegable (visible en móviles y tablets) -->
    <div x-show="isOpen" @click.away="isOpen = false" class="xl:hidden bg-white text-[#162C48] mt-2"
        x-transition:enter="transition ease-out duration-300" 
        x-transition:enter-start="opacity-0 transform scale-95" 
        x-transition:enter-end="opacity-100 transform scale-100" 
        x-transition:leave="transition ease-in duration-200" 
        x-transition:leave-start="opacity-100 transform scale-100" 
        x-transition:leave-end="opacity-0 transform scale-95">
        <div class="px-4 py-6 space-y-4">
            <a href="#home" class="block hover:text-azul-secondary"><?php echo e(__('site.home')); ?></a>
            <a href="#services" class="block hover:text-azul-secondary"><?php echo e(__('site.services')); ?></a>
            <a href="#information" class="block hover:text-azul-secondary"><?php echo e(__('site.fund')); ?></a>
            <a href="#team" class="block hover:text-azul-secondary"><?php echo e(__('site.team')); ?></a>
            <a href="#faq" class="block hover:text-azul-secondary"><?php echo e(__('site.faq')); ?></a>
            <a href="#docs" class="block hover:text-azul-secondary"><?php echo e(__('site.docs')); ?></a>
            <a href="#contact" class="block hover:text-azul-secondary"><?php echo e(__('site.contact')); ?></a>
        </div>
        <div class="items-center space-x-6">
            <div class="flex items-center space-x-2 m-2">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('system.language-selector');

$__html = app('livewire')->mount($__name, $__params, 'lw-2390008740-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="flex items-center space-x-2 m-1">
                <i class="fas fa-lock text-sm"></i>
                <a href="<?php echo e(route('login')); ?>"><span><?php echo e(__('site.login')); ?></span></a>
            </div>
            <div class="flex justify-end">
                <button class="bg-azul-secondary hover:bg-azul-primary text-white px-4 py-2 m-2 rounded-lg font-medium">
                    <?php echo e(__('site.invest_now')); ?>

                </button>
            </div>
        </div>
    </div>
</nav>

    <!-- Hero Section -->
    <div id="home">
    <section class="relative w-full h-[900px] bg-black text-white overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-r from-black to-transparent opacity-70"></div>
        <!-- Imagen transparente -->
        <img 
            src="<?php echo e(asset('images/Hero background.webp')); ?>" 
            alt="Imagen transparente" 
            class="absolute inset-0 w-full h-full object-cover opacity-50"
        />
        <div class="container mx-auto px-4 py-16 md:py-24 relative z-10">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
                        <?php echo e(__('site.hero_text_1')); ?>

                    </h1>
                    <p class="text-xl mb-8"><?php echo e(__('site.hero_text_2')); ?></p>
                    <a href="<?php echo e(asset('documents/Asset Performance Fund LLC - BROCHURE VERTICAL.pdf')); ?>" target="_blank">
                        <button class="bg-azul-secondary hover:bg-azul-primary px-6 py-3 rounded-lg font-medium transition">
                            <?php echo e(__('site.hero_text_3')); ?>

                        </button>
                    </a>
                </div>
                <div class="relative">
                    <img src="<?php echo e(asset('images/GRAFICO HERO.webp')); ?>" alt="Gráfico de crecimiento" class="w-full rounded-lg">
                </div>
            </div>
        </div>
        
        <div class="absolute right-0 bottom-10 mb-4 text-center text-xs text-white opacity-70 mr-4">
            <span class="transform rotate-90"><?php echo e(__('site.hero_text_4')); ?></span>
            <i class="fa-solid fa-caret-down mt-2 block animate-bounce"></i>
        </div>
    </section>

    </div>
    

    <!-- Servicios de inversión confiable -->
    <section id="services" class="py-16 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                
                <div class="relative w-full">
                    <!-- Imagen -->
                    <img 
                        src="<?php echo e(asset('images/Servicios.webp')); ?>" 
                        alt="Edificio moderno" 
                        class="w-full rounded-2xl shadow-lg h-[500px] md:h-[600px] lg:h-[700px] object-cover"
                    />

                    <!-- Máscara de color -->
                    <div class="absolute inset-0 bg-azul-primary opacity-50 rounded-2xl"></div>
                </div>
                <div>
                    <h2 class="text-3xl md:text-5xl lg:text-6xl text-azul-primary mb-6 font-figtree font-bold"><?php echo e(__('site.services_title')); ?></h2>
                    <ul class="space-y-4">
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree">
                                <?php echo e(__('site.services_text_1')); ?></h2>
                            </span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3 pl-1"></i>
                            <span class="text-xl lg:text-2xl font-figtree pl-1">
                                <?php echo e(__('site.services_text_2')); ?>

                            </span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree">
                                <?php echo e(__('site.services_text_3')); ?>

                            </span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><?php echo e(__('site.services_text_4')); ?></span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><?php echo e(__('site.services_text_5')); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Información de Asset Found -->
    <section id="information" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 class="text-3xl md:text-5xl lg:text-6xl font-figtree font-bold text-azul-primary mb-4"><?php echo e(__('site.fund_title')); ?></h2>
                    <h3 class="text-2xl font-figtree font-semibold text-azul-primary mb-6"><?php echo e(__('site.fund_subtitle')); ?></h3>
                    <ul class="space-y-4">
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><strong><?php echo e(__('site.fund_text_1_title')); ?></strong> <?php echo e(__('site.fund_text_1')); ?></span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><strong><?php echo e(__('site.fund_text_2_title')); ?></strong> <?php echo e(__('site.fund_text_2')); ?></span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><strong><?php echo e(__('site.fund_text_3_title')); ?></strong> <?php echo e(__('site.fund_text_3')); ?></span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><strong><?php echo e(__('site.fund_text_4_title')); ?></strong> <?php echo e(__('site.fund_text_4')); ?></span>
                        </li>
                        <li class="flex items-center">
                            <i class="fa-solid fa-check text-xl lg:text-2xl text-azul-secondary mr-3"></i>
                            <span class="text-xl lg:text-2xl font-figtree"><strong><?php echo e(__('site.fund_text_5_title')); ?></strong> <?php echo e(__('site.fund_text_5')); ?></span>
                        </li>
                    </ul>
                </div>
                <div class="relative w-full">
                    <!-- Imagen -->
                    <img 
                        src="<?php echo e(asset('images/Asset Found Information.webp')); ?>" 
                        alt="Edificio moderno" 
                        class="w-full rounded-2xl shadow-lg h-[500px] md:h-[600px] lg:h-[700px] object-cover"
                    />

                    <!-- Máscara de color -->
                    <div class="absolute inset-0 bg-azul-primary opacity-50 rounded-2xl"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Nuestros Proyectos -->
    <section id="projects" class="py-16 bg-white">
        <div class="container mx-auto">
            <h2 class="text-5xl lg:text-6xl font-figtree font-bold text-azul-primary text-center mb-4"><?php echo e(__('site.projects_title')); ?></h2>
            <p class="text-center text-2xl lg:text-3xl text-azul-primary font-figtree mb-2"><?php echo e(__('site.projects_subtitle')); ?></p>
            <div class="relative w-full">
                <img src="<?php echo e(asset('images/Construccion.webp')); ?>" alt="Sitio de construcción con grúas" class="w-full shadow-sm">
                <div class="absolute inset-0 bg-white opacity-20 rounded-2xl"></div>

            </div>
        </div>
    </section>

    <!-- Equipo Gestor -->
    <section id="team" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div class="relative">
                    <img src="<?php echo e(asset('images/Alvaro Bazan.webp')); ?>" alt="Álvaro Bazan" class="w-3/4 mx-auto rounded-2xl shadow-lg">
                    
                </div>
                <div>
                    <h2 class="text-3xl md:text-5xl lg:text-6xl font-figtree font-bold text-azul-primary mb-2"><?php echo e(__('site.team_title')); ?></h2>
                    <p class="text-xl lg:text-2xl text-azul-primary mb-8"><?php echo e(__('site.team_subtitle')); ?></p>
                    
                    <div class="bg-white p-6 rounded-xl shadow-lg">
                        <h3 class="text-4xl lg:text-5xl font-figtree font-bold text-azul-secondary mb-2">Álvaro Bazan</h3>
                        <p class="text-xl lg:text-2xl text-gray-500 font-figtree mb-4"><?php echo e(__('site.team_subtitle_2')); ?></p>
                        <p class="text-lg text-gray-700 leading-relaxed">
                            <?php echo e(__('site.team_text_1')); ?>

                            <br><br>
                            <?php echo e(__('site.team_text_2')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Dónde Operamos -->
    <section id="where" class="py-16 bg-white mt-0 mb-0">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl font-bold text-blue-900 text-center mb-12"><?php echo e(__('site.where_title')); ?></h2>
            
            <div class="grid md:grid-cols-4 gap-8 items-center">
                <div class="bg-white p-6 rounded-xl shadow-md border-b-4 border-azul-secondary h-[600px] lg:h-[300px]">
                    <div class="flex justify-center mb-4">
                        <img src="<?php echo e(asset('images/Donde operamos icon-01.svg')); ?>"  class="text-azul-secondary h-[128px]"></img>
                    </div>
                    <p class="text-center text-gray-700">
                        <?php echo e(__('site.where_text_1')); ?>

                    </p>
                </div>
                
                <div class="bg-white p-6 rounded-xl shadow-md border-b-4 border-azul-secondary h-[600px] lg:h-[300px]">
                    <div class="flex justify-center mb-4">
                        <img src="<?php echo e(asset('images/Donde operamos icon-02.svg')); ?>"  class="text-azul-secondary h-[128px]"></img>
                    </div>
                    <p class="text-center text-gray-700">
                        <?php echo e(__('site.where_text_2')); ?>

                    </p>
                </div>
                
                <div class="bg-white p-6 col-span-2">
                    <img src="<?php echo e(asset('images/Mapa USA corregido.webp')); ?>" alt="Mapa de EE.UU. con estados destacados" class="w-full h-auto">
                </div>
            </div>
            
        </div>
    </section>
    <div class="relative mt-0 mb-0 overflow-hidden">
        <img src="<?php echo e(asset('images/Mesa Arizona.webp')); ?>" alt="Panorama de la ciudad de Mesa, Arizona" class="w-full h-[600px] object-cover opacity-60">

        <!-- Gradiente difuminado -->
        <div class="absolute inset-0 bg-gradient-to-b from-white to-transparent"></div>
    </div>


    <!-- Historical y rendimiento -->
    <section id="performance" class="relative w-full h-50vh bg-black text-white overflow-hidden">
        
        <!-- Imagen transparente -->
        <img 
            src="<?php echo e(asset('images/Historial y Rendimiento Background.webp')); ?>" 
            alt="Imagen transparente" 
            class="absolute inset-0 w-full h-[900px] object-cover opacity-10"
        />
        <div class="container mx-auto px-4 py-16 md:py-24 relative z-10">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 class="text-3xl md:text-6xl font-figtree font-bold text-center mb-12 mt-0"><?php echo e(__('site.perf_title')); ?></h2>
                    <div class="flex justify-between">
                        <div class="text-center ml-4 md:ml-8"> 
                            <div class="text-4xl md:text-5xl font-bold text-azul-secondary">+10</div>
                            <div class="text-sm"><?php echo e(__('site.perf_text_1')); ?></div>
                        </div>
                        <div class="text-center mr-4 md:mr-8">
                            <div class="text-4xl md:text-5xl font-bold text-azul-secondary">$3,894,567</div>
                            <div class="text-sm"><?php echo e(__('site.perf_text_2')); ?></div>
                        </div>
                    </div>
                    <div class="flex justify-between mt-4">
                        <div class="text-center ml-4 md:ml-8">
                            <div class="text-4xl md:text-5xl font-bold text-azul-secondary">145</div>
                            <div class="text-sm"><?php echo e(__('site.perf_text_3')); ?></div>
                        </div>
                        <div class="text-center mr-4 md:mr-8">
                            <div class="text-4xl md:text-5xl font-bold text-azul-secondary">7% -10%</div>
                            <div class="text-sm"><?php echo e(__('site.perf_text_4')); ?></div>
                        </div>
                    </div>
                    
                </div>
                
                <div class="flex justify-center items-center">
                <img 
                    src="<?php echo e(asset('images/Metrica icon.webp')); ?>" 
                    alt="Gráfico de crecimiento" 
                    class="w-full md:w-4/5 lg:w-3/5 max-w-[400px] mx-auto rounded-lg"
                />
            </div>
            </div> 
        </div>
    </section>


    <!-- Preguntas Frecuentes -->
    <section id="faq" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl md:text-6xl font-bold font-figtree text-azul-secondary mb-8 mx-auto text-left"><?php echo e(__('site.faq_title')); ?></h2>
            
            <div class="grid md:grid-cols-2 gap-8">
                

                <div class="container mx-auto px-4 py-14">
                    <div class="space-y-4">
                        <!-- Pregunta 1 -->
                        <div x-data="{ open: false }" class="border rounded-lg overflow-hidden">
                            <!-- Botón para abrir/cerrar -->
                            <button 
                                @click="open = !open"
                                class="w-full text-left font-figtree font-bodd text-lg md:text-2xl px-6 py-4 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:bg-gray-200 transition"
                            >
                                <div class="flex items-center justify-between">
                                    <span class="font-medium text-gray-800"><?php echo e(__('site.faq_text_1_title')); ?></span>
                                    
                                    <i class="fa-solid fa-chevron-down font-bold text-lg md:text-2xl"></i>
                                </div>
                            </button>

                            <!-- Contenido que se muestra/oculta -->
                            <div x-show="open" x-collapse class="px-6 py-4 bg-white text-gray-700 font-figtree text-lg md:text-2xl">
                                <p><?php echo e(__('site.faq_text_1')); ?></p>
                            </div>
                        </div>

                        <!-- Pregunta 2 -->
                        <div x-data="{ open: false }" class="border rounded-lg overflow-hidden">
                            <button 
                                @click="open = !open"
                                class="w-full text-left font-figtree font-bodd text-lg md:text-2xl px-6 py-4 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:bg-gray-200 transition"
                            >
                                <div class="flex items-center justify-between">
                                    <span class="font-medium text-gray-800"><?php echo e(__('site.faq_text_2_title')); ?></span>
                                    
                                    <i class="fa-solid fa-chevron-down font-bold text-lg md:text-2xl"></i>
                                </div>
                            </button>
                            <div x-show="open" x-collapse class="px-6 py-4 bg-white text-gray-700 font-figtree text-lg md:text-2xl">
                                <p><p><?php echo e(__('site.faq_text_2')); ?></p></p>
                            </div>
                        </div>

                        <!-- Pregunta 3 -->
                        <div x-data="{ open: false }" class="border rounded-lg overflow-hidden">
                            <button 
                                @click="open = !open"
                                class="w-full text-left font-figtree font-bodd text-lg md:text-2xl px-6 py-4 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:bg-gray-200 transition"
                            >
                                <div class="flex items-center justify-between">
                                    <span class="font-medium text-gray-800"><?php echo e(__('site.faq_text_3_title')); ?></span>
                                    
                                    <i class="fa-solid fa-chevron-down font-bold text-lg md:text-2xl"></i>
                                </div>
                            </button>
                            <div x-show="open" x-collapse class="px-6 py-4 bg-white text-gray-700 font-figtree text-lg md:text-2xl">
                                <p><p><?php echo e(__('site.faq_text_3')); ?></p></p>
                            </div>
                        </div>

                        <!-- Pregunta 4 -->
                        <div x-data="{ open: false }" class="border rounded-lg overflow-hidden">
                            <button 
                                @click="open = !open"
                                class="w-full text-left font-figtree font-bodd text-lg md:text-2xl px-6 py-4 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:bg-gray-200 transition"
                            >
                                <div class="flex items-center justify-between">
                                    <span class="font-medium text-gray-800"><?php echo e(__('site.faq_text_4_title')); ?></span>
                                    
                                    <i class="fa-solid fa-chevron-down font-bold text-lg md:text-2xl"></i>
                                </div>
                            </button>
                            <div x-show="open" x-collapse class="px-6 py-4 bg-white text-gray-700 font-figtree text-lg md:text-2xl">
                                <p><p><?php echo e(__('site.faq_text_4')); ?></p></p>
                            </div>
                        </div>

                        <!-- Agrega más preguntas aquí -->
                    </div>
                </div>




                <div>
                    <img src="<?php echo e(asset('images/Preguntas frecuentes.webp')); ?>" alt="Rascacielos modernos" class="w-2/3 mx-auto rounded-2xl shadow-lg">
                </div>
            </div>
                
        </div>
    </section>

    <section id="docs" class="relative w-full bg-white py-16">
        <!-- Contenedor principal -->
        <div class="container mx-auto px-4">
            <!-- Recuadro con imagen de fondo transparente -->
            <div class="max-w-7x h-50vh mx-auto relative rounded-2xl overflow-hidden shadow-lg">
                <!-- Imagen de fondo transparente -->
                <img 
                    src="<?php echo e(asset('images/Documentacion y Cumplimiento.webp')); ?>" 
                    alt="Imagen transparente" 
                    class="absolute inset-0 w-full h-full object-cover opacity-80"
                />

                <!-- Capa semitransparente para el fondo -->
                <div class="absolute inset-0 bg-azul-primary opacity-80"></div>

                <!-- Contenido del recuadro -->
                <div class="relative p-8 text-center rounded-2xl">
                    <h2 class="text-4xl md:text-6xl font-figtree font-bold text-white mb-6 md:mt-16"><p><?php echo e(__('site.docs_title')); ?></p></h2>
                    <p class="text-gray-300 mb-8 font-figtree"><?php echo e(__('site.docs_subtitle')); ?></p>

                    <!-- Botones -->
                    <div class="flex flex-wrap justify-center gap-4">
                        <a href="<?php echo e(asset('documents/Asset Performance Fund LLC - BROCHURE VERTICAL.pdf')); ?>" target="_blank">
                            <button class="font-figtree hover:font-bold text-xl bg-azul-secondary hover:bg-azul-primary px-6 py-3 rounded-lg font-medium transition text-white md:mb-16">
                                <?php echo e(__('site.docs_button_1')); ?>

                            </button>
                        </a>
                        <a href="<?php echo e(asset('documents/APF Existing Investor Subscription Agreement.pdf')); ?>" target="_blank">
                            <button class="font-figtree hover:font-bold text-xl bg-azul-secondary hover:bg-azul-primary px-6 py-3 rounded-lg font-medium transition text-white md:mb-16">
                                <?php echo e(__('site.docs_button_2')); ?>

                            </button>
                        </a>
                        <a href="<?php echo e(asset('documents/APF New Investor Subscription Agreement.pdf')); ?>" target="_blank">
                            <button class="font-figtree hover:font-bold text-xl bg-azul-secondary hover:bg-azul-primary px-6 py-3 rounded-lg font-medium transition text-white md:mb-16">
                                <?php echo e(__('site.docs_button_3')); ?>

                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Footer -->
    <footer id="contact" class="bg-azul-primary text-white py-12">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 gap-8">
                <div>
                    <img src="<?php echo e(asset('images/Logo APF blanco.png')); ?>" alt="Asset Performance Fund" class="h-16 md:h-20 xl:h-24 mb-12">
                    <div class="space-y-3 mb-12">
                        <div class="flex items-center space-x-3">
                            <i class="fa-solid fa-location-dot text-lg md:text-xl"></i>
                            <span class="font-figtree text-lg md:text-xl">3134 E McKellips Rd #31, Mesa, AZ 85213.</span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <i class="fa-solid fa-envelope text-lg md:text-xl"></i>
                            <span class="font-figtree text-lg md:text-xl">invest@assetperformancefund.com</span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <i class="fa-solid fa-phone text-lg md:text-xl"></i>
                            <span class="font-figtree text-lg md:text-xl">480-334-2788</span>
                        </div>
                    </div>
                    <div class="flex space-x-4">
                        <a href="#" class="text-2xl md:text-3xl hover:text-azul-secondary"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-2xl md:text-3xl hover:text-azul-secondary"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-2xl md:text-3xl hover:text-azul-secondary"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-2xl md:text-5xl font-figtree font-bold mb-4"><?php echo e(__('site.contact_title')); ?></h3>
                    <p class="mb-6 text-lg md:text-xl font-figtree"><?php echo e(__('site.contact_text')); ?></p>
                    <button class="text-xl md:text-2xl font-figtree hover:font-bold bg-azul-secondary hover:bg-azul-primary px-8 py-3 rounded-lg font-medium transition w-full md:w-auto">
                        <?php echo e(__('site.contact_button')); ?>

                    </button>
                </div>
            </div>
            
            <div class="border-t border-blue-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
                <div class="flex space-x-6 text-sm text-gray-400 mb-4 md:mb-0">
                    <a href="<?php echo e(route('privacy')); ?>" class="hover:text-white"><?php echo e(__('site.footer_text_1')); ?></a>
                    <a href="<?php echo e(route('terms')); ?>" class="hover:text-white"><?php echo e(__('site.footer_text_2')); ?></a>
                    <a href="<?php echo e(route('legal')); ?>" class="hover:text-white"><?php echo e(__('site.footer_text_3')); ?></a>
                </div>
                <div class="text-sm text-gray-400">
                    © 2025 <?php echo e(__('site.footer_text_4')); ?>

                </div>
            </div>
        </div>
    </footer>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e)): ?>
<?php $attributes = $__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e; ?>
<?php unset($__attributesOriginalfefb4fd9b7004fa65f70c415ac76903e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfefb4fd9b7004fa65f70c415ac76903e)): ?>
<?php $component = $__componentOriginalfefb4fd9b7004fa65f70c415ac76903e; ?>
<?php unset($__componentOriginalfefb4fd9b7004fa65f70c415ac76903e); ?>
<?php endif; ?><?php /**PATH /home/gpg/Code/laravel/investments/resources/views/system/home.blade.php ENDPATH**/ ?>