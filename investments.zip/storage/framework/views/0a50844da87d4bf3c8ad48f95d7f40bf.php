<div>
    <div class="w-full flex">
        <select wire:model.live="language" class="form-select">
            <option value="en">🇺🇸 <?php echo e(__('language.english')); ?></option>
            
            <option value="es">🇲🇽 <?php echo e(__('language.spanish')); ?></option>
        </select>
    </div>
    
</div><?php /**PATH /home/gpg/Code/laravel/investments/resources/views/livewire/system/language-selector.blade.php ENDPATH**/ ?>