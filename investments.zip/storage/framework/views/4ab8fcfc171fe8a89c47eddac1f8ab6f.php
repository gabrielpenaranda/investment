
<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php
        $formatter = new NumberFormatter(app()->getLocale(), NumberFormatter::DECIMAL);
        $formatter->setAttribute(NumberFormatter::MIN_FRACTION_DIGITS, 2);
    ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('system.language-selector');

$__html = app('livewire')->mount($__name, $__params, 'lw-3612849433-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <div  class="mb-8 flex justify-between items-center">
        <?php if (isset($component)) { $__componentOriginalbbbea167ab072e3e3621cf7b736152aa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbbbea167ab072e3e3621cf7b736152aa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::breadcrumbs.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
            <?php if (isset($component)) { $__componentOriginalced986e8ff6641d3797206c3198c2b83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalced986e8ff6641d3797206c3198c2b83 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::breadcrumbs.item','data' => ['href' => ''.e(route('admin.dashboard')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::breadcrumbs.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.dashboard')).'']); ?>
                <?php echo e(__('messages.Dashboard')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalced986e8ff6641d3797206c3198c2b83)): ?>
<?php $attributes = $__attributesOriginalced986e8ff6641d3797206c3198c2b83; ?>
<?php unset($__attributesOriginalced986e8ff6641d3797206c3198c2b83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalced986e8ff6641d3797206c3198c2b83)): ?>
<?php $component = $__componentOriginalced986e8ff6641d3797206c3198c2b83; ?>
<?php unset($__componentOriginalced986e8ff6641d3797206c3198c2b83); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalced986e8ff6641d3797206c3198c2b83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalced986e8ff6641d3797206c3198c2b83 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::breadcrumbs.item','data' => ['href' => ''.e(route('admin.interests.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::breadcrumbs.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.interests.index')).'']); ?>
                <?php echo e(__('messages.Interests')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalced986e8ff6641d3797206c3198c2b83)): ?>
<?php $attributes = $__attributesOriginalced986e8ff6641d3797206c3198c2b83; ?>
<?php unset($__attributesOriginalced986e8ff6641d3797206c3198c2b83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalced986e8ff6641d3797206c3198c2b83)): ?>
<?php $component = $__componentOriginalced986e8ff6641d3797206c3198c2b83; ?>
<?php unset($__componentOriginalced986e8ff6641d3797206c3198c2b83); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalced986e8ff6641d3797206c3198c2b83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalced986e8ff6641d3797206c3198c2b83 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::breadcrumbs.item','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::breadcrumbs.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php echo e(__('messages.Show')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalced986e8ff6641d3797206c3198c2b83)): ?>
<?php $attributes = $__attributesOriginalced986e8ff6641d3797206c3198c2b83; ?>
<?php unset($__attributesOriginalced986e8ff6641d3797206c3198c2b83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalced986e8ff6641d3797206c3198c2b83)): ?>
<?php $component = $__componentOriginalced986e8ff6641d3797206c3198c2b83; ?>
<?php unset($__componentOriginalced986e8ff6641d3797206c3198c2b83); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbbbea167ab072e3e3621cf7b736152aa)): ?>
<?php $attributes = $__attributesOriginalbbbea167ab072e3e3621cf7b736152aa; ?>
<?php unset($__attributesOriginalbbbea167ab072e3e3621cf7b736152aa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbbbea167ab072e3e3621cf7b736152aa)): ?>
<?php $component = $__componentOriginalbbbea167ab072e3e3621cf7b736152aa; ?>
<?php unset($__componentOriginalbbbea167ab072e3e3621cf7b736152aa); ?>
<?php endif; ?>

         <a href="<?php echo e(route('admin.interests.index')); ?>" class="btn btn-danger"><?php echo e(__('messages.Return to list')); ?></a>
    </div>

    <div class="card">
        <p class="text-2xl mb-4"><?php echo e(__('messages.Show Interest')); ?></p>
        
        <?php if($interest->investment->is_active): ?>
            <p class="text-xl mb-4"><?php echo e(__('messages.Investment Information')); ?></p>
        <?php else: ?>
            <p class="text-xl mb-4"><?php echo e(__('messages.Closed Investment Information')); ?></p>
        <?php endif; ?>

        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Serial')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Client')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Email')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Investment Amount')); ?> USD
                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Opening Date')); ?>

                    </th>

                    <?php if($interest->investment->deactivation_date != null): ?>
                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Closing Date')); ?>

                    </th>
                    <?php endif; ?>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Capitalizable Interests')); ?>

                    </th>

                </tr>
            </thead>
            <tbody>
                <tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700 border-gray-200">
                    
                    <td class="px-6 py-4">
                        <?php echo e($interest->investment->serial); ?>

                    </td>

                    <td class="px-6 py-4">
                        <?php echo e($interest->investment->name); ?>

                    </td>

                    <td class="px-6 py-4">
                        <?php echo e($interest->investment->email); ?>

                    </td>
                    
                    <td class="px-6 py-4 text-center">
                        <?php echo e($formatter->format(round($interest->investment->investment_amount, 2))); ?>

                    </td>

                    <td class="px-6 py-4 text-center">
                        <?php
                            $activation_date = app()->getLocale() === 'es' ? date("d/m/Y", strtotime($interest->investment->activation_date)) : date("m/d/Y", strtotime($interest->investment->activation_date));
                        ?>
                        <?php echo e($activation_date); ?>

                    </td>

                    <?php if($interest->investment->deactivation_date != null): ?>
                        <td class="px-6 py-4 text-center">
                                <?php
                                    $deactivation_date = app()->getLocale() === 'es' ? date("d/m/Y", strtotime($interest->investment->deactivation_date)) : date("m/d/Y", strtotime($interest->investment->deactivation_date));
                                ?>
                                <?php echo e($deactivation_date); ?>

                        </td>
                    <?php endif; ?>

                    <td class="px-6 py-4 text-center">
                        <?php if($interest->investment->capitalize): ?>
                            Yes
                        <?php else: ?>
                            No
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="text-xl mb-4 mt-8"><?php echo e(__('messages.Interest Information')); ?></p>
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Serial')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Interest Amount')); ?> USD
                    </th>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Process')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Condition')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Status')); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700 border-gray-200">
                    
                    <td class="px-6 py-4">
                        <?php echo e($interest->serial); ?>

                    </td>

                    <td class="px-6 py-4 text-center">
                        <?php echo e($formatter->format(round($interest->interest_amount, 2))); ?>

                    </td>

                    <td class="px-6 py-4">
                        <?php if($interest->approved): ?>
                            <?php echo e(__('messages.Approved')); ?>

                        <?php else: ?>
                            <?php echo e(__('messages.Pending')); ?>

                        <?php endif; ?>
                    </td>
                    
                    <td class="px-6 py-4 text-center">
                        <?php if($interest->condition == 'paid'): ?>
                            <?php echo e(__('messages.Paid')); ?>

                        <?php else: ?>
                            <?php echo e(__('messages.Unpaid')); ?>

                        <?php endif; ?>
                    </td>

                    <td class="px-6 py-4 text-center">
                        <?php if($interest->status == 'payable'): ?>
                            <?php echo e(__('messages.Payable')); ?>

                        <?php else: ?>
                            <?php echo e(__('messages.Cumulative')); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <p class="text-md mb-4 mt-8"><?php echo e(__('messages.Transaction Records')); ?></p>
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Starting Date')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Ending Date')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3">
                        <?php echo e(__('messages.Investment Amount')); ?> USD
                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Rate')); ?> %
                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Days')); ?>

                    </th>

                    <th scope="col" class="px-6 py-3 text-center">
                        <?php echo e(__('messages.Interests')); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $investmentChanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investmentChange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700 border-gray-200">
                        
                        <td class="px-6 py-4">
                            <?php
                            $activation_date = app()->getLocale() === 'es' ? date("d/m/Y", strtotime($investmentChange->activation_date)) : date("m/d/Y", strtotime($investmentChange->activation_date));
                            ?>
                            <?php echo e($activation_date); ?>

                        </td>

                        <td class="px-6 py-4">
                            <?php
                            $deactivation_date = app()->getLocale() === 'es' ? date("d/m/Y", strtotime($investmentChange->deactivation_date)) : date("m/d/Y", strtotime($investmentChange->deactivation_date));
                            ?>
                            <?php echo e($deactivation_date); ?>

                        </td>

                        <td class="px-6 py-4 text-center">
                            <?php echo e($formatter->format(round($investmentChange->amount, 2))); ?>

                        </td>

                        <td class="px-6 py-4 text-center">
                             <?php echo e($formatter->format($investmentChange->rate)); ?>

                        </td>
                        
                        <td class="px-6 py-4 text-center">
                            <?php echo e($investmentChange->total_days); ?>

                        </td>

                        <td class="px-6 py-4 text-center">
                            <?php echo e($formatter->format(round($investmentChange->interests, 2))); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?><?php /**PATH /home/gpg/Code/laravel/investments/resources/views/system/admin/interests/show.blade.php ENDPATH**/ ?>