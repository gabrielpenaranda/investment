<?php echo e($slot); ?>

<?php /**PATH /home/gpg/Code/laravel/investments/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>