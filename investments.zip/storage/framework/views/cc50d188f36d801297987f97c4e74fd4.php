<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Account Statement - <?php echo e($investment->name); ?></title>
    <link rel="icon" href="<?php echo e(asset('favicon/favicon.ico')); ?>" sizes="any">
    <link rel="icon" href="<?php echo e(asset('favicon/favicon.svg')); ?>" type="image/svg+xml">
    <style>
        /* Estilo general */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 10pt; /* Tamaño de fuente para PDF */
            color: #333;
        }

        .page {
            width: 21cm; /* Ancho A4 */
            height: 29.7cm; /* Alto A4 */
            margin: auto;
            padding: 1cm 1cm 2.5cm 1cm; /* Margen inferior más grande para el pie de página */
            box-sizing: border-box;
            page-break-after: always;
        }

        /* Encabezado */
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.5cm;
            padding-bottom: 0.5cm;
            border-bottom: 1px solid #ccc;
        }

        .logo-placeholder img {
            width: 120px;
            height: 42px;
        }

        .header-info {
            text-align: right;
        }

        .header-info h4 {
            margin: 0 0 6pt;
            font-size: 14pt;
        }

        .header-info p {
            margin: 0 0 4pt;
            font-size: 9pt;
        }

        /* Tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10pt;
        }

        th {
            background-color: #f2f2f2;
            padding: 6pt;
            text-align: center;
            border: 1px solid #ddd;
            font-weight: bold;
            font-size: 9pt;
        }

        td {
            padding: 6pt;
            border: 1px solid #ddd;
            font-size: 9pt;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #fafafa;
        }

        /* Pie de página */
        .footer {
            position: absolute;
            bottom: 1cm; /* Fija el pie de página al fondo */
            left: 1cm;
            right: 1cm;
            text-align: center;
            font-size: 8pt;
            color: #777;
            border-top: 1px solid #eee;
            padding-top: 0.5cm;
        }

        /* Forzar salto de página si es necesario */
        .page-break {
            page-break-before: always;
        }
    </style>
</head>
<body>
    <?php
        $numPage = 0;
        $counter = 0;
        $formatter = new NumberFormatter(app()->getLocale(), NumberFormatter::DECIMAL);
        $formatter->setAttribute(NumberFormatter::MIN_FRACTION_DIGITS, 2);
    ?>
    <div class="page">
        <!-- Encabezado -->
        <div class="header">
            <div class="logo-placeholder">
                
                <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('images/Logo APF color.png')))); ?>" alt="Logo">
            </div>
            <div class="header-info">
                <h4><?php echo e(__('messages.Account Statement')); ?></h4>
                <p><strong><?php echo e($investment->name); ?></strong></p>
                <p><?php echo e($investment->user->address); ?></p>
                <p><?php echo e($investment->user->state->code); ?>, <?php echo e($investment->user->zip_code); ?></p>
            </div>
        </div>

        <!-- Contenido -->
        <div class="content">
            <?php $__currentLoopData = $account_statements->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table>
                    <thead>
                        <tr>
                            <th><?php echo e(__('messages.Date')); ?></th>
                            <th><?php echo e(__('messages.Description')); ?></th>
                            <th><?php echo e(__('messages.Contributions')); ?> USD</th>
                            <th><?php echo e(__('messages.Distributions')); ?> USD</th>
                            <th><?php echo e(__('messages.Account Balance')); ?> USD</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td tyle="text-align: center;">
                                    <?php
                                        $date = app()->getLocale() === 'es' ? date("d/m/Y", strtotime($state->date)) : date("m/d/Y", strtotime($state->date));
                                    ?>
                                    <?php echo e($date); ?>

                                </td>
                                <td tyle="text-align: left;"><?php echo e($state->description); ?></td>
                                <td style="text-align: right;">
                                    <?php if($state->type == 'contribution'): ?>
                                        
                                        <?php echo e($formatter->format(round($state->amount, 2))); ?>

                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    <?php if($state->type == 'distribution'): ?>
                                        
                                        <?php echo e($formatter->format(round($state->amount, 2))); ?>

                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    
                                    <?php echo e($formatter->format(round($state->balance, 2))); ?>

                                </td>
                            </tr>
                            <?php
                                $counter++;
                                if ($counter == 10) {
                                    $counter = 0;
                                }
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php
                    $numPage++;
                ?>
                <div class="footer">
                    <?php echo e(__('messages.Page')); ?> <?php echo e($numPage ?? 1); ?> — <?php echo e(__('messages.Confidential. Generated on')); ?> <?php echo e(now()->format('m/d/Y')); ?>.
                </div>
                <?php if($counter == 0): ?>
                    <div class="page-break"></div>
                    <div class="header">
                        <div class="logo-placeholder">
                            
                            <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('images/Logo APF color.png')))); ?>" alt="Logo">
                        </div>
                        <div class="header-info">
                            <h4><?php echo e(__('messages.Account Statement')); ?></h4>
                            <p><strong><?php echo e($investment->name); ?></strong></p>
                            <p><?php echo e($investment->user->address); ?></p>
                            <p><?php echo e($investment->user->state->code); ?>, <?php echo e($investment->user->zip_code); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pie de página -->
        
    </div>

</body>
</html><?php /**PATH /home/gpg/Code/laravel/investments/resources/views/system/admin/account-statements/print2.blade.php ENDPATH**/ ?>