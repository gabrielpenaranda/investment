

<img src="<?php echo e(asset('images/Logo APF color.png')); ?>" alt="">
<?php /**PATH /home/gpg/Code/laravel/investments/resources/views/components/app-logo-icon.blade.php ENDPATH**/ ?>