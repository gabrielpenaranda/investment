

<img src="<?php echo e(asset('images/Logo APF blanco.png')); ?>" alt="">
<?php /**PATH /home/gpg/Code/laravel/investments/resources/views/components/app-logo-icon-white.blade.php ENDPATH**/ ?>