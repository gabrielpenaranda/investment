<?php $__env->startComponent('mail::message'); ?>
# Hello <?php echo new \Illuminate\Support\EncodedHtmlString($user->name); ?>,

Your account has been created.

**Email:** <?php echo new \Illuminate\Support\EncodedHtmlString($user->email); ?>  
**Password:** <?php echo new \Illuminate\Support\EncodedHtmlString($password); ?>


Please login and change your password immediately.

<?php $__env->startComponent('mail::button', ['url' => route('login')]); ?>
Login Now
<?php echo $__env->renderComponent(); ?>

Thanks,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/gpg/Code/laravel/investments/resources/views/emails/user/credentials.blade.php ENDPATH**/ ?>