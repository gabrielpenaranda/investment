<div class="relative mb-6 w-full">
    <flux:heading size="xl" level="1">{{ __('Password') }}</flux:heading>
    <flux:subheading size="lg" class="mb-6">{{ __('messages.Change your password') }}</flux:subheading>
    <flux:separator variant="subtle" />
</div>
