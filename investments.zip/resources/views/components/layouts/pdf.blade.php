<x-layouts.app.pdf :title="$title ?? null">
        {{ $slot }}

</x-layouts.app.pdf>
