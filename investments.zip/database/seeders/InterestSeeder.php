<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\system\InterestMonth;

class InterestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /* InterestMonth::create([
            'year' => '2025',
            'month' => '05',
            'processed' => true,
            'approved' => true,
        ]);

        InterestMonth::create([
            'year' => '2025',
            'month' => '06',
            'processed' => true,
            'approved' => true,
        ]);

        InterestMonth::create([
            'year' => '2025',
            'month' => '07',
            'processed' => true,
            'approved' => true,
        ]);

        InterestMonth::create([
            'year' => '2025',
            'month' => '08',
            'processed' => false,
            'approved' => false,
        ]); */
    }
}
