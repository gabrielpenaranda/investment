<?php

namespace App\Livewire\System\Admin;

use Livewire\Component;

class WithdrawalsIndex extends Component
{
    public function render()
    {
        return view('livewire.system.admin.withdrawals-index');
    }
}
