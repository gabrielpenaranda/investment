<?php

namespace App\Http\Requests\system;

use Illuminate\Foundation\Http\FormRequest;

class ReportCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
         if (auth()->user()) {
            return true;
        } else {
            return false;
        };
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|unique:reports',
            'year' => 'required|integer|between:1990,2099',
            'month' => 'required|integer|between:1,12',
            'file' => 'required|file|mimetypes:application/pdf, application/x-pdf',
            'published' => 'boolean',
        ];
    }
}
