<?php

namespace App\Http\Requests\system;

use Illuminate\Foundation\Http\FormRequest;

class ProductUpdateRequest extends ProductCreateRequest
{
    //
}
